#!/bin/sh 
cp wpa_supplicant /media/NAND1-1/ssv_wifi/wpa_supplicant_ssv 
cp wpa_cli /media/NAND1-1/ssv_wifi/wpa_cli_ssv 
sync
